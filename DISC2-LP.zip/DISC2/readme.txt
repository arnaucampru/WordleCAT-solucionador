Diccionari Informatitzat de l'Scrabble en Català, versió 2.7.15 - 27/09/2019
----------------------------------------------------------------------------

Copyright 2012 -- 2019 Joan Montané joan(sense_spam)montane.cat

El «Diccionari Informatitzat de l'Scrabble en Català», DISC, té una llicència dual GPLv3 i CC-by-sa v3, a la vostra elecció

Per a més informació, visiteu:

http://diccionari.totescrable.cat


«Diccionari Informatitzat de l'Scrabble en Català» (DISC) is under a dual license (at your choose): GPLv3 and CC-by-sa v3

For more info, read (in Catalan):

http://diccionari.totescrable.cat


